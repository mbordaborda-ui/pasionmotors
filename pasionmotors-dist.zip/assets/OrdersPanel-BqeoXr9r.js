import{f as G,ag as b,Y as R,j as e,ab as F,w as M,p as u,aa as f,k as E,U as H,x as P,G as V,W as K,s as I}from"./index-BwVJZVq-.js";import{r as c}from"./react-vendor-Um8d7DHd.js";import{P as X}from"./phone--f2qNch6.js";import{C as Y}from"./credit-card-BTeCwmrh.js";import{E as B}from"./external-link-DCBPiJ8n.js";import{S as Q}from"./save-BvUsz_yD.js";import"./supabase-vendor-f4bNl52y.js";/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=G("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=G("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]),n=t=>String(t??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");function J(t){const s=Object.entries(t.selections??{}).map(([m,o])=>`${m}: ${o}`).join(", "),r=s?` (${s})`:"";return`${t.qty} × ${t.name}${r}`}function Z(t){const s=t.customer,r=t.items.slice(0,6),m=Math.max(0,t.items.length-r.length),o=t.id.slice(0,8).toUpperCase();return`<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Guía ${n(o)} · PASION MOTORS</title>
  <style>
    @page { size: 100mm 150mm; margin: 0; }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; background: #fff; color: #111; }
    body { font-family: Arial, Helvetica, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .label {
      width: 100mm;
      height: 150mm;
      padding: 5mm;
      display: flex;
      flex-direction: column;
      gap: 2.5mm;
      overflow: hidden;
    }
    .header { display: flex; align-items: flex-end; justify-content: space-between; border-bottom: 0.6mm solid #111; padding-bottom: 2mm; }
    .brand { font-size: 15px; font-weight: 900; letter-spacing: 0.5px; }
    .brand span { color: #FF1E2D; }
    .tag { font-size: 6px; letter-spacing: 2px; color: #555; text-transform: uppercase; }
    .doc { font-size: 7px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #FF1E2D; }
    .eyebrow { margin: 0 0 0.8mm; font-size: 6px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.2px; color: #777; }
    .section { border: 0.3mm solid #ccc; border-radius: 2mm; padding: 2mm 2.5mm; }
    .name { margin: 0; font-size: 12px; font-weight: 800; line-height: 1.15; }
    .line { margin: 0.6mm 0 0; font-size: 8px; line-height: 1.35; }
    .address { margin: 0; font-size: 11px; font-weight: 700; line-height: 1.25; }
    .city { margin: 0.8mm 0 0; font-size: 10px; font-weight: 700; text-transform: uppercase; }
    .items { margin: 0; padding: 0; list-style: none; }
    .items li { font-size: 7.5px; line-height: 1.35; border-bottom: 0.2mm dotted #ddd; padding: 0.4mm 0; }
    .items li:last-child { border-bottom: none; }
    .notes { font-size: 7.5px; line-height: 1.35; }
    .notes-section { background: #f4f4f4; border-color: #999; }
    .notes-clamp {
      display: -webkit-box;
      -webkit-line-clamp: 4;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .footer { margin-top: auto; border-top: 0.3mm dashed #999; padding-top: 1.5mm; display: flex; justify-content: space-between; gap: 3mm; font-size: 6.5px; color: #555; }
    .sign { border-top: 0.2mm solid #555; width: 45mm; padding-top: 0.8mm; text-align: center; }
    @media print {
      html, body { width: 100mm; height: 150mm; }
      .label { width: 100mm; height: 150mm; }
    }
  </style>
</head>
<body>
  <div class="label">
    <div class="header">
      <div>
        <div class="brand">PASION <span>MOTORS</span></div>
        <div class="tag">Drive the passion</div>
      </div>
      <div class="doc">Guía de envío</div>
    </div>

    <div class="section">
      <p class="eyebrow">Destinatario</p>
      <p class="name">${n(s.name)}</p>
      <p class="line">CC / Documento: ${n(s.document||"—")}</p>
      <p class="line">Tel: ${n(s.phone)}</p>
      <p class="line">${n(s.email)}</p>
    </div>

    <div class="section">
      <p class="eyebrow">Dirección de entrega</p>
      <p class="address">${n(s.address)}</p>
      <p class="city">${n(s.city)}</p>
    </div>

    <div class="section">
      <p class="eyebrow">Remitente</p>
      <p class="name" style="font-size:10px">${n(b.name)}</p>
      <p class="line">CC / Documento: ${n(b.document)}</p>
      <p class="line">${n(b.address)}</p>
    </div>

    <div class="section">
      <p class="eyebrow">Contenido (${t.count} ${t.count===1?"artículo":"artículos"})</p>
      <ul class="items">
        ${r.map(d=>`<li>${n(J(d))}</li>`).join("")}
      </ul>
      ${m>0?`<p class="line">+ ${m} ítem(s) adicional(es)</p>`:""}
    </div>

    ${s.notes?`<div class="section notes-section"><p class="eyebrow">Observaciones del cliente</p><p class="notes notes-clamp">${n(s.notes)}</p></div>`:""}

    <div class="footer">
      <div class="sign">Recibido por</div>
      <div class="sign">Fecha / hora</div>
    </div>
  </div>
  <script>
    window.addEventListener('load', function () {
      window.focus();
      setTimeout(function () { window.print(); }, 250);
    });
    window.addEventListener('afterprint', function () { window.close(); });
  <\/script>
</body>
</html>`}function L(t){const s=window.open("","_blank","width=460,height=700");return s?(s.document.open(),s.document.write(Z(t)),s.document.close(),!0):!1}const T={pending:{label:"Pendiente",className:"border-amber-300/30 bg-amber-300/10 text-amber-200"},paid:{label:"Pagado",className:"border-emerald-400/30 bg-emerald-400/10 text-emerald-300"},failed:{label:"Fallido",className:"border-brand/40 bg-brand/10 text-brand-300"},refunded:{label:"Reembolsado",className:"border-sky-400/30 bg-sky-400/10 text-sky-300"},expired:{label:"Expirado",className:"border-white/15 bg-white/5 text-white/50"},cancelled:{label:"Cancelado",className:"border-white/15 bg-white/5 text-white/50"}};function ee({order:t,onCancel:s}){const[r,m]=c.useState(!1),[o,i]=c.useState(!1),[d,_]=c.useState(t.trackingNumber??""),[w,z]=c.useState(t.trackingCarrier??u),[v,A]=c.useState(t.trackingUrl??f),[N,g]=c.useState(!1),[j,y]=c.useState(!1),[k,C]=c.useState(""),[S,x]=c.useState(""),{refresh:D}=R(),$=T[t.status]??T.pending,U=async()=>{g(!0),C(""),x("");const a=d.trim(),p=v.trim(),{error:h}=await I.from("orders").update({tracking_number:a||null,tracking_carrier:w.trim()||u,tracking_url:p||f,shipped_at:a?t.shippedAt??new Date().toISOString():null}).eq("id",t.id);if(h){g(!1),C(h.message);return}if(await D(),a){const{data:l,error:q}=await I.functions.invoke("send-order-email",{body:{orderId:t.id,type:"shipping"}});q||!(l!=null&&l.ok)?x((l==null?void 0:l.error)==="not_configured"?"Guía guardada. Para enviarla por correo configura RESEND_API_KEY y ORDER_FROM_EMAIL.":(l==null?void 0:l.error)==="order_not_paid"?"Guía guardada. El pedido aún no está pagado; el correo se envía cuando se confirme el pago.":"Guía guardada, pero no se pudo enviar el correo al cliente."):x("Guía guardada y enviada al correo del cliente.")}g(!1),y(!0),window.setTimeout(()=>y(!1),1800),window.setTimeout(()=>x(""),7e3)};return e.jsxs("div",{className:"card-surface p-5",children:[e.jsxs("div",{className:"flex flex-wrap items-start justify-between gap-3",children:[e.jsxs("div",{children:[e.jsx("p",{className:"font-mono text-sm text-white",children:t.id}),e.jsxs("div",{className:"mt-1 flex flex-wrap items-center gap-2",children:[e.jsx("p",{className:"text-xs text-white/45",children:new Date(t.createdAt).toLocaleString("es-CO")}),e.jsx("span",{className:`rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${$.className}`,children:$.label})]})]}),e.jsxs("div",{className:"text-right",children:[e.jsx("p",{className:"font-display text-xl uppercase tracking-tight text-white",children:E(t.total)??"Por confirmar"}),e.jsxs("p",{className:"text-xs text-white/45",children:[t.count," ",t.count===1?"artículo":"artículos"]})]})]}),e.jsxs("div",{className:"mt-4 grid gap-2 text-sm text-white/70 sm:grid-cols-2",children:[e.jsxs("p",{className:"flex items-center gap-2",children:[e.jsx(H,{className:"h-4 w-4 text-brand"})," ",t.customer.name]}),e.jsxs("p",{className:"flex items-center gap-2",children:[e.jsx(X,{className:"h-4 w-4 text-brand"})," ",t.customer.phone]}),e.jsxs("p",{className:"flex items-center gap-2",children:[e.jsx(Y,{className:"h-4 w-4 text-brand"})," ",t.customer.document||"Sin documento"]}),e.jsx("p",{className:"truncate",children:t.customer.email}),e.jsxs("p",{className:"sm:col-span-2 text-white/50",children:[t.customer.address,", ",t.customer.city]})]}),t.trackingNumber&&e.jsxs("div",{className:"mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-sky-400/20 bg-sky-400/[0.06] px-3 py-2 text-xs text-sky-100",children:[e.jsx(P,{className:"h-4 w-4 shrink-0 text-sky-300"}),e.jsxs("span",{children:["Guía ",e.jsx("strong",{className:"font-mono text-white",children:t.trackingNumber}),t.trackingCarrier?` · ${t.trackingCarrier}`:""]}),t.trackingUrl&&e.jsxs("a",{href:t.trackingUrl,target:"_blank",rel:"noreferrer",className:"ml-auto inline-flex items-center gap-1 font-semibold text-sky-300 transition hover:text-white",children:["Consultar ",e.jsx(B,{className:"h-3.5 w-3.5"})]})]}),e.jsxs("div",{className:"mt-4 flex flex-wrap items-center justify-between gap-3",children:[e.jsx("button",{onClick:()=>m(a=>!a),className:"text-[11px] font-semibold uppercase tracking-wider text-white/50 transition hover:text-white",children:r?"Ocultar detalle":"Ver detalle"}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("button",{onClick:()=>{L(t)||alert("Permite las ventanas emergentes del navegador para imprimir la guía.")},className:"inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/10 px-3 text-[11px] font-semibold uppercase tracking-wider text-white/60 transition hover:border-brand hover:text-white","aria-label":"Imprimir guía de envío",title:"Imprimir guía de envío",children:[e.jsx(O,{className:"h-4 w-4"})," Guía"]}),s&&e.jsxs("button",{onClick:async()=>{o||confirm("¿Cancelar este pedido pendiente? Se libera el stock reservado y la acción no se puede deshacer.")&&(i(!0),await s(),i(!1))},disabled:o,className:"inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/10 px-3 text-[11px] font-semibold uppercase tracking-wider text-white/50 transition hover:border-brand hover:text-brand disabled:opacity-50","aria-label":"Cancelar pedido pendiente",title:"Cancelar pedido y liberar stock",children:[e.jsx(W,{className:"h-4 w-4"})," ",o?"Cancelando…":"Cancelar"]})]})]}),r&&e.jsxs("div",{className:"mt-4 space-y-3 border-t border-white/10 pt-4",children:[e.jsx("ul",{className:"space-y-1.5 text-sm text-white/70",children:t.items.map((a,p)=>e.jsxs("li",{className:"flex justify-between gap-3",children:[e.jsxs("span",{className:"truncate",children:[a.qty," × ",a.name,Object.keys(a.selections).length>0&&e.jsxs("span",{className:"ml-2 text-xs text-white/40",children:["(",Object.entries(a.selections).map(([h,l])=>`${h}: ${l}`).join(", "),")"]})]}),e.jsx("span",{className:"shrink-0",children:E(a.price)??"—"})]},p))}),t.gifts.length>0&&e.jsxs("div",{className:"rounded-xl border border-brand/20 bg-brand/[0.05] p-3",children:[e.jsxs("p",{className:"flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-brand-300",children:[e.jsx(V,{className:"h-3.5 w-3.5"})," Regalos incluidos"]}),e.jsx("ul",{className:"mt-1.5 list-inside list-disc text-xs text-white/70",children:t.gifts.map((a,p)=>e.jsx("li",{children:a},p))})]}),t.customer.notes&&e.jsxs("p",{className:"text-xs text-white/50",children:[e.jsx("span",{className:"font-semibold text-white/70",children:"Notas:"})," ",t.customer.notes]}),t.paymentId&&e.jsxs("p",{className:"text-xs text-white/40",children:[e.jsx("span",{className:"font-semibold text-white/60",children:"Pago:"})," ",e.jsx("span",{className:"font-mono",children:t.paymentId})]}),t.termsAcceptedAt&&e.jsxs("p",{className:"text-xs text-white/40",children:[e.jsx("span",{className:"font-semibold text-white/60",children:"Términos:"})," aceptados el"," ",new Date(t.termsAcceptedAt).toLocaleString("es-CO"),t.termsVersion?` · versión ${t.termsVersion}`:""]}),e.jsxs("div",{className:"rounded-xl border border-white/10 bg-white/[0.02] p-3",children:[e.jsxs("p",{className:"flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white/60",children:[e.jsx(P,{className:"h-3.5 w-3.5 text-brand"})," Seguimiento del envío"]}),e.jsxs("div",{className:"mt-3 grid gap-2 sm:grid-cols-2",children:[e.jsx("input",{value:d,onChange:a=>_(a.target.value),className:"field !py-2 !text-xs",placeholder:"Número de guía"}),e.jsx("input",{value:w,onChange:a=>z(a.target.value),className:"field !py-2 !text-xs",placeholder:u}),e.jsx("input",{value:v,onChange:a=>A(a.target.value),className:"field !py-2 !text-xs sm:col-span-2",placeholder:f,type:"url"})]}),k&&e.jsxs("p",{className:"mt-2 text-[11px] text-brand-300",children:["No se pudo guardar: ",k]}),S&&e.jsx("p",{className:"mt-2 text-[11px] leading-relaxed text-emerald-200/80",children:S}),e.jsx("button",{onClick:U,disabled:N,className:j?"btn-primary mt-3 !py-2 !text-[11px] !bg-emerald-500":"btn-primary mt-3 !py-2 !text-[11px]",children:j?e.jsxs(e.Fragment,{children:[e.jsx(K,{className:"h-3.5 w-3.5"})," Guía guardada"]}):e.jsxs(e.Fragment,{children:[e.jsx(Q,{className:"h-3.5 w-3.5"})," ",N?"Guardando...":"Guardar guía"]})}),e.jsxs("p",{className:"mt-2 text-[11px] leading-relaxed text-white/35",children:["Al guardar el número de guía se envía automáticamente al cliente el correo con el enlace de ",u," (solo si el pedido está pagado). El cliente también verá la guía y el enlace en su cuenta y en la página de Envíos."]}),e.jsxs("button",{onClick:()=>{L(t)||alert("Permite las ventanas emergentes del navegador para imprimir la guía.")},className:"btn-ghost mt-3 w-full !py-2 !text-[11px]",children:[e.jsx(O,{className:"h-3.5 w-3.5"})," Imprimir guía (100 × 150 mm)"]})]})]})]})}function ce(){const{orders:t,cancelOrder:s}=R(),[r,m]=c.useState(""),o=c.useMemo(()=>{const i=r.trim().toLowerCase();return i?t.filter(d=>d.id.toLowerCase().includes(i)||d.customer.name.toLowerCase().includes(i)||d.customer.email.toLowerCase().includes(i)||d.customer.phone.toLowerCase().includes(i)||(d.trackingNumber??"").toLowerCase().includes(i)):t},[t,r]);return e.jsxs("div",{className:"space-y-6",children:[e.jsx("div",{className:"flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",children:e.jsxs("div",{className:"flex w-full max-w-xs items-center gap-2 rounded-full border border-white/10 bg-ink-800/70 px-4 py-2",children:[e.jsx(F,{className:"h-4 w-4 text-white/40"}),e.jsx("input",{value:r,onChange:i=>m(i.target.value),placeholder:"Buscar por cliente o pedido…",className:"w-full bg-transparent py-1.5 text-sm text-white placeholder-white/40 outline-none"})]})}),e.jsxs("div",{className:"rounded-2xl border border-white/10 bg-white/[0.02] p-4 text-xs leading-relaxed text-white/50",children:["Los pedidos no se pueden eliminar: son el registro contable de la tienda. Si un pedido pendiente ya no se va a pagar, puedes ",e.jsx("strong",{className:"text-white/70",children:"cancelarlo"})," y el stock vuelve al inventario. Los pedidos pagados se conservan para garantías, facturación y auditoría."]}),o.length===0?e.jsxs("div",{className:"flex flex-col items-center gap-3 rounded-3xl border border-dashed border-white/15 bg-white/[0.02] p-12 text-center",children:[e.jsx(M,{className:"h-8 w-8 text-white/30"}),e.jsx("p",{className:"text-sm text-white/55",children:t.length===0?"Aún no hay pedidos. Se registran al confirmar una compra en el checkout.":"No hay pedidos que coincidan con la búsqueda."})]}):e.jsx("div",{className:"grid gap-4 lg:grid-cols-2",children:o.map(i=>e.jsx(ee,{order:i,onCancel:i.status==="pending"?()=>s(i.id).then(()=>{}):void 0},i.id))})]})}export{ce as OrdersPanel};
